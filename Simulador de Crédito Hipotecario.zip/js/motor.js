(function (raiz) {
  'use strict';

  const P = (typeof module !== 'undefined' && module.exports) ? require('./parametros.js') : raiz.PARAMETROS;

  const mesesCada = ({ desde, hasta, cada }) => {
    const meses = [];
    for (let k = desde; k <= hasta; k += cada) meses.push(k);
    return meses;
  };
  const MESES_INCREMENTO = mesesCada(P.CALENDARIO.incrementoPago);
  const MESES_INCREMENTO_APORTACION = mesesCada(P.CALENDARIO.incrementoAportacion);
  const NUM_PERIODOS = P.CALENDARIO.periodos;

  const num = (x) => (x === null || x === undefined || x === '' || Number.isNaN(x) ? 0 : x);
  const vacio = (x) => x === null || x === undefined || x === '';

  function restar(a, b) {
    const r = a - b;
    return Math.abs(r) <= 4e-15 * Math.max(Math.abs(a), Math.abs(b)) ? 0 : r;
  }

  function sumar(a, b) {
    return restar(a, -b);
  }

  function diasDelMes(anio, mes) {
    return new Date(Date.UTC(anio, mes, 0)).getUTCDate();
  }

  function leerFecha(texto) {
    const [a, m, d] = String(texto).split('-').map(Number);
    return { anio: a, mes: m, dia: d };
  }

  function fechaPrimerPago(fecha) {
    const diaCorte = (fecha.dia >= 3 && fecha.dia <= 16) ? 3 : 17;
    const corrimiento = fecha.dia > diaCorte ? 1 : 0;
    const base = new Date(Date.UTC(fecha.anio, fecha.mes - 1 + corrimiento, diaCorte));
    return { anio: base.getUTCFullYear(), mes: base.getUTCMonth() + 1, dia: base.getUTCDate(), diaCorte };
  }

  function buscarAvaluo(valor) {
    let importe = null;
    for (const [desde, monto] of P.AVALUOS) {
      if (valor >= desde) importe = monto;
      else break;
    }
    return importe === null ? 0 : importe;
  }

  function tir(flujos) {
    const vpn = (r) => flujos.reduce((s, f, t) => s + f / Math.pow(1 + r, t), 0);
    const dvpn = (r) => flujos.reduce((s, f, t) => s - t * f / Math.pow(1 + r, t + 1), 0);
    let r = 0;
    for (let i = 0; i < 100; i++) {
      const f = vpn(r);
      const d = dvpn(r);
      if (d === 0 || !Number.isFinite(f)) return null;
      const siguiente = r - f / d;
      if (!Number.isFinite(siguiente) || siguiente <= -1) return null;
      if (Math.abs(siguiente - r) < 1e-13) return siguiente;
      r = siguiente;
    }
    return Math.abs(vpn(r)) < 1e-6 ? r : null;
  }

  function aforoPorPerfil(tipo, entrada) {
    if (typeof tipo.aforo === 'number') return tipo.aforo;
    const i = entrada.indiceTasa - 1;
    if (tipo.aforo === 'conApoyo') return num(P.AFOROS.conApoyo[i]);
    if (entrada.actividad === 1) return num(P.AFOROS.empleado[i]);
    const tabla = (tipo.id === 4 || tipo.id === 5) ? P.AFOROS.independientePasivo : P.AFOROS.independiente;
    return num(tabla[i]);
  }

  function condicionesFinancieras(entrada) {
    const campana = P.CAMPANAS[entrada.campana - 1];
    const plazo = P.PLAZOS[entrada.plazo - 1];
    const esValora = entrada.producto === 1;
    const po = campana.pagosOportunos[plazo.anios];

    const opcionesTasa = esValora
      ? P.INDICES_RIESGO.map((_, i) => {
        if (i === 0 && plazo.anios === 7) return null;
        return campana.valora[i] ? campana.valora[i].tasa : null;
      })
      : P.INDICES_RIESGO.map((_, i) => (i === 0 ? po.tasa : null));

    const tasa = esValora ? opcionesTasa[entrada.indiceTasa - 1] : opcionesTasa[0];
    const renglonValora = esValora && !vacio(tasa) ? campana.valora.find((v) => v.tasa === tasa) : null;

    let ppm = null;
    let incremento = null;
    if (!esValora) {
      ppm = po.ppm;
      incremento = 0;
    } else if (plazo.anios !== 7 && renglonValora) {
      ppm = renglonValora.ppm[plazo.anios];
      incremento = renglonValora.incremento;
    }

    return {
      campana, plazo, esValora, opcionesTasa,
      tasa: vacio(tasa) ? null : tasa,
      ppm, incremento,
      piso: campana.piso, techo: campana.techo,
      valida: !vacio(tasa) && !vacio(ppm)
    };
  }

  function tasasPorPeriodo(cond) {
    const tasas = new Array(NUM_PERIODOS + 1).fill(null);
    if (cond.esValora) {
      let t = cond.tasa;
      const { desdeMes, hastaMes, cadaMeses, reduccion } = P.AJUSTES_TASA.valora;
      for (let k = 1; k <= NUM_PERIODOS; k++) {
        if (k >= desdeMes && k <= hastaMes && (k - desdeMes) % cadaMeses === 0) {
          if (t !== cond.piso) {
            const reducida = t - reduccion;
            t = reducida <= cond.piso ? cond.piso : reducida;
          }
        }
        tasas[k] = t;
      }
    } else {
      let t = cond.campana.pagosOportunos[cond.plazo.anios].tasa;
      for (let k = 1; k <= cond.plazo.meses; k++) {
        const ajuste = P.AJUSTES_TASA.pagosOportunos[k];
        if (ajuste) t = t - ajuste;
        tasas[k] = t;
      }
    }
    return tasas;
  }

  function montosDelCredito(entrada, tipo, cond, aforo) {
    const dato = num(entrada.dato);
    const modo = entrada.modoCalculo;
    const ppm = cond.ppm;

    const creditoPorValor = modo === 3 ? dato : dato * aforo;
    const valorPorValor = modo === 3 ? dato / aforo : dato;
    const pagoPorIngreso = dato * tipo.pti;
    const creditoPorIngreso = vacio(ppm) || ppm === 0 ? 0 : pagoPorIngreso / (ppm / 1000);
    const valorPorIngreso = creditoPorIngreso / aforo;

    const porValor = modo === 1 || modo === 3;
    const creditoBase = porValor ? creditoPorValor : creditoPorIngreso;
    const valorVivienda = porValor ? valorPorValor : valorPorIngreso;

    const ssvTitular = num(entrada.ssvTitular);
    const creditoInfTitular = num(entrada.creditoInfonavitTitular);
    const ssvConyugeCofinavit = num(entrada.ssvConyugeCofinavit);
    const creditoInfConyuge = num(entrada.creditoInfonavitConyuge);
    const ssvConyugeCICB = num(entrada.ssvConyugeCICB);

    const aforoCofinavit = P.TIPOS_CREDITO[2].aforo;
    const aforoCICB = P.TIPOS_CREDITO[6].aforo;

    const cofinavit = (() => {
      const recursosInfonavit = creditoInfTitular + creditoInfConyuge + ssvTitular + ssvConyugeCofinavit;
      const porcentajeInfonavit = valorVivienda ? recursosInfonavit / valorVivienda : 0;
      const creditoAforoMaximo = aforoCofinavit * valorVivienda;
      const exceso = aforoCofinavit + porcentajeInfonavit > 1 ? aforoCofinavit + porcentajeInfonavit - 1 : 0;
      return { porcentajeInfonavit, creditoAforoMaximo, exceso, creditoAjustado: creditoAforoMaximo - exceso * valorVivienda };
    })();

    const cicb = (() => {
      const montoAutorizado = valorVivienda * aforoCICB;
      const ssv = ssvTitular + ssvConyugeCICB;
      const otorgado = valorVivienda > montoAutorizado + ssv ? montoAutorizado : valorVivienda - ssv;
      const porcentaje = valorVivienda ? otorgado / valorVivienda : null;
      const creditoInfonavit = Math.min(P.INFONAVIT.montoMaximoCICB, otorgado * P.INFONAVIT.porcionCICB);
      return { montoAutorizado, ssv, otorgado, porcentaje, creditoInfonavit, creditoBanco: otorgado - creditoInfonavit };
    })();

    let creditoDisponible = creditoBase;
    if (tipo.id === 3) creditoDisponible = cofinavit.creditoAjustado;
    if (tipo.id === 7) creditoDisponible = cicb.creditoBanco;

    const perfilApoyo = [1, 4, 6].includes(tipo.id) ? 1 : 0;
    const perfilValora = !cond.esValora ? 1 : (entrada.indiceTasa > 3 ? 1 : 0);
    const creditoPorLTI = (modo === 2 && cond.esValora && entrada.indiceTasa > 3 && perfilApoyo + perfilValora > 0)
      ? dato * P.LTI_VALORA : null;

    const creditoMaximo = creditoPorLTI === null ? creditoDisponible : creditoPorLTI;
    const creditoSolicitado = vacio(entrada.creditoSolicitado) ? creditoMaximo : Number(entrada.creditoSolicitado);

    return {
      dato, valorVivienda, creditoMaximo, creditoSolicitado, creditoPorLTI, pagoPorIngreso,
      cofinavit, cicb, perfilApoyo, perfilValora,
      ssvTitular, creditoInfTitular, ssvConyugeCofinavit, creditoInfConyuge, ssvConyugeCICB
    };
  }

  function gastosFinanciadosPasivo(entrada, tipo, m, aforo) {
    if (tipo.id !== 4 && tipo.id !== 5) return null;
    if (entrada.gastosFinanciados === 'NO') return 0;
    const tasa = P.GASTOS.gastosFinanciadosPasivo;
    if (entrada.modoCalculo === 1 && m.valorVivienda * aforo === m.creditoSolicitado) return 0;
    if (entrada.modoCalculo === 1 && m.creditoSolicitado * tasa + m.creditoSolicitado > m.creditoMaximo) {
      return m.creditoMaximo - m.creditoSolicitado;
    }
    return m.creditoSolicitado * tasa;
  }

  function gastosDeOriginacion(entrada, tipo, m, financiados, comisionApertura) {
    const esInfonavit = tipo.id === 3 || tipo.id === 7;
    const creditoInfonavit = tipo.id === 3 ? m.creditoInfTitular + m.creditoInfConyuge
      : (tipo.id === 7 ? m.cicb.creditoInfonavit : null);
    const ssvAlFrente = tipo.id === 3 ? m.ssvTitular + m.ssvConyugeCofinavit
      : (tipo.id === 7 ? m.ssvTitular + m.ssvConyugeCICB : null);

    const infonavitOriginacion = esInfonavit ? creditoInfonavit * P.GASTOS.infonavitOriginacion : null;
    const v = m.valorVivienda;
    const impuestos = vacio(entrada.impuestosManual) ? v * P.GASTOS.impuestosDerechos : v * entrada.impuestosManual;
    const honorarios = vacio(entrada.honorariosManual) ? v * P.GASTOS.honorariosNotariales : v * entrada.honorariosManual;
    const avaluo = [2, 3].includes(entrada.campana) || [4, 5].includes(tipo.id) ? 0 : buscarAvaluo(v);
    const comision = [2, 3, 4, 5].includes(entrada.campana) || entrada.tipoComision === 2
      ? 0 : m.creditoSolicitado * comisionApertura;

    const suma = num(infonavitOriginacion) + impuestos + honorarios + avaluo + comision;
    const total = financiados === null ? suma : suma - financiados;

    return {
      esInfonavit, creditoInfonavit, ssvAlFrente, infonavitOriginacion, impuestos, honorarios, avaluo, comision, total,
      porcentajeImpuestos: vacio(entrada.impuestosManual) ? (v ? impuestos / v : 0) : null,
      porcentajeHonorarios: vacio(entrada.honorariosManual) ? (v ? honorarios / v : 0) : null,
      cotizarAvaluo: v > P.AVALUO_LIMITE_COTIZAR
    };
  }

  function corridaCAT(B0, cond, tasas, ctx) {
    const filas = [];
    const ppm = num(cond.ppm);
    let vivo = true;
    let incrementoBase = 0;
    let prev = null;
    const f0 = ctx.primerPago;

    for (let k = 1; k <= NUM_PERIODOS; k++) {
      let saldo;
      if (k === 1) saldo = B0;
      else if (k <= 14) saldo = prev.saldoFinal;
      else saldo = prev.saldoFinal <= 0 ? 0 : prev.saldoFinal;

      if (saldo === 0) vivo = false;
      const fecha = new Date(Date.UTC(f0.anio, f0.mes - 1 + (k - 1), 1));
      const dias = vivo ? diasDelMes(fecha.getUTCFullYear(), fecha.getUTCMonth() + 1) : 0;

      const tasa = saldo === 0 ? null : tasas[k];
      const interes = vacio(tasa) ? 0 : tasa / P.DIAS_ANIO_COMERCIAL * dias * saldo;

      let incremento = 0;
      if (k === 13) {
        incremento = saldo <= 0 ? 0 : num(cond.incremento);
        incrementoBase = incremento;
      } else if (MESES_INCREMENTO.includes(k)) {
        incremento = saldo <= 0 ? 0 : incrementoBase;
      }

      let pago;
      if (k === 1) pago = B0 / 1000 * ppm;
      else pago = restar(saldo + interes, prev.pago) < 0 ? saldo + interes : prev.pago * (1 + incremento);

      const amortizacion = restar(pago, interes);
      const saldoFinal = restar(saldo, amortizacion);
      const seguros = ctx.segurosExternos ? 0
        : (saldo <= 0.01 ? 0 : saldo * P.SEGUROS.vidaDesempleo) + (saldo <= 0.01 ? 0 : ctx.valorDanios * P.SEGUROS.danios);

      const fila = { k, saldo, pago, interes, amortizacion, saldoFinal, tasa, seguros, dias, incremento, flujo: interes + amortizacion + seguros, factor: saldo ? pago / saldo : 0 };
      filas.push(fila);
      prev = fila;
    }
    return filas;
  }

  function tablaAmortizacion(B0, cond, tasas, sombra, ctx) {
    const filas = [];
    const ppm = num(cond.ppm);
    const aportacionTope = P.INFONAVIT.uma * P.INFONAVIT.topeVecesUma * P.INFONAVIT.aportacionPatronal * P.INFONAVIT.diasBimestre;
    let prev = null;
    let prevPrev = null;
    let liquidaAnios = 0;
    let liquidaMeses = 0;
    let liquidaPeriodo = null;

    for (let k = 1; k <= NUM_PERIODOS; k++) {
      const s = sombra[k - 1];
      const saldo = k === 1 ? B0 : (prev.saldoFinal <= 0 ? 0 : prev.saldoFinal);
      const tasa = saldo === 0 ? null : tasas[k];
      const interes = saldo === 0 || vacio(tasa) ? 0 : tasa / P.DIAS_ANIO_COMERCIAL * s.dias * saldo;
      const incremento = MESES_INCREMENTO.includes(k) ? (saldo <= 0 ? 0 : num(cond.incremento)) : 0;

      let erogacion;
      if (k === 1) {
        erogacion = saldo / 1000 * ppm;
      } else if (restar(saldo + interes, prev.erogacion) <= 0) {
        erogacion = saldo + interes;
      } else if ((ctx.tipo === 2 || ctx.tipo === 7) && prev.prepago === 0) {
        erogacion = prev.erogacion * (1 + incremento);
      } else if (ctx.reduccion === 2) {
        erogacion = saldo * s.factor;
      } else {
        erogacion = prev.erogacion * (1 + incremento);
      }

      const amortizacion = restar(erogacion, interes);
      const prepago = num(ctx.prepagos[k]);
      const penalizacion = ctx.tipoComision === 1 ? 0 : prepago * ctx.comisionPrepago * (1 + P.IVA);

      let aportacion = 0;
      if (k === 2) {
        if (ctx.tipo === 2 || ctx.tipo === 5) {
          const bimestral = ctx.sueldoCotizacion * P.INFONAVIT.aportacionPatronal * 2;
          aportacion = bimestral > aportacionTope ? aportacionTope : (saldo === 0 ? 0 : bimestral);
        }
      } else if (k > 2 && k % 2 === 0) {
        const factor = MESES_INCREMENTO_APORTACION.includes(k) ? 1 + P.INFONAVIT.incrementoAnualAportacion : 1;
        aportacion = restar(saldo, amortizacion) === 0 ? 0 : prevPrev.aportacion * factor;
      }

      let saldoFinal = restar(saldo, amortizacion);
      saldoFinal = restar(saldoFinal, prepago);
      saldoFinal = sumar(saldoFinal, penalizacion);
      saldoFinal = restar(saldoFinal, aportacion);

      const seguroVida = ctx.segurosExternos || saldo <= 0 ? 0 : saldo * P.SEGUROS.vidaDesempleo;
      const seguroDanios = ctx.segurosExternos || saldo <= 0 ? 0 : ctx.valorDanios * P.SEGUROS.danios;
      const pagoMensual = saldo <= 0 ? 0 : erogacion + prepago + seguroVida + seguroDanios;

      if (saldoFinal <= 0 && (k === 1 || prev.saldoFinal > 0)) {
        liquidaAnios += Math.floor(k / 12);
        liquidaMeses += k === 1 ? (saldo === 0 ? 0 : 1) : k % 12;
        if (liquidaPeriodo === null) liquidaPeriodo = k;
      }

      const fila = { k, saldo, erogacion, interes, amortizacion, prepago, penalizacion, aportacion, tasa: saldo === 0 ? null : tasa, saldoFinal, seguroVida, seguroDanios, pagoMensual, dias: s.dias };
      filas.push(fila);
      prevPrev = prev;
      prev = fila;
    }

    const total = (campo) => filas.reduce((acc, f) => acc + f[campo], 0);
    return {
      filas,
      liquidaAnios, liquidaMeses, liquidaPeriodo,
      totales: {
        erogacion: total('erogacion'), interes: total('interes'), amortizacion: total('amortizacion'),
        prepago: total('prepago'), seguroVida: total('seguroVida'), seguroDanios: total('seguroDanios'),
        pagoMensual: total('pagoMensual')
      }
    };
  }

  function mensajes(entrada, tipo, m, cond, condicionesTipo) {
    const dato = entrada.dato;
    const avisos = {};
    if (vacio(dato) || dato === 0) avisos.dato = '';
    else if (entrada.modoCalculo === 1 && dato < condicionesTipo.valorMinimo) avisos.dato = 'Valor de vivienda debajo del mínimo';
    else if (dato < condicionesTipo.ingresoMinimo) avisos.dato = 'Ingresos menores al mínimo';
    else avisos.dato = '';

    if (m.creditoSolicitado === 0) avisos.credito = '';
    else if (m.creditoSolicitado > m.creditoMaximo) avisos.credito = 'Crédito fuera de rango';
    else if (m.creditoSolicitado < condicionesTipo.creditoMinimo) avisos.credito = 'Crédito debajo del mínimo';
    else avisos.credito = '';

    const montoMaximoPolitica = entrada.indiceTasa === 5 ? P.MONTO_MAXIMO_POLITICA.indiceR : P.MONTO_MAXIMO_POLITICA.general;
    if (vacio(dato)) avisos.linea = '';
    else if (entrada.modoCalculo === 3 && m.creditoMaximo > montoMaximoPolitica) avisos.linea = 'El crédito solicitado debe ser igual al máximo';
    else if (m.perfilApoyo === 1 && m.perfilValora === 1) avisos.linea = 'Línea máxima a otorgar puede ser menor por perfil del cliente';
    else avisos.linea = '';

    avisos.combinacion = cond.valida ? '' : 'La combinación de producto, plazo y tasa no está disponible';
    return avisos;
  }

  function ingresoMinimoRequerido(entrada, tipo, cond, credito) {
    const { anios } = cond.plazo;
    let ppm;
    if (!cond.esValora) {
      ppm = cond.campana.pagosOportunos[anios].ppm;
    } else {
      if (anios === 7) return 0;
      const renglon = cond.campana.valora[entrada.indiceTasa - 1];
      ppm = renglon ? renglon.ppm[anios] : null;
    }
    const porCredito = vacio(ppm) ? 0 : credito / 1000 * ppm / tipo.pti;
    return Math.max(tipo.ingresoMinimo, porCredito);
  }

  function cotizar(entrada) {
    const tipo = P.TIPOS_CREDITO[entrada.tipoCredito - 1];
    const cond = condicionesFinancieras(entrada);
    const aforo = aforoPorPerfil(tipo, entrada);
    const comisionApertura = vacio(entrada.comisionManual) ? tipo.comisionApertura : entrada.comisionManual;

    const m = montosDelCredito(entrada, tipo, cond, aforo);
    const financiados = gastosFinanciadosPasivo(entrada, tipo, m, aforo);
    const montoConFinanciados = financiados !== null && financiados > 0 ? m.creditoSolicitado + financiados : null;
    const montoCredito = montoConFinanciados === null ? m.creditoSolicitado : montoConFinanciados;

    const gastos = gastosDeOriginacion(entrada, tipo, m, financiados, comisionApertura);

    const porcentajeFinanciamiento = m.valorVivienda === 0 ? 0
      : (tipo.id === 7 ? m.cicb.porcentaje : montoCredito / m.valorVivienda);

    const fueraDeRango = m.creditoSolicitado > m.creditoMaximo;
    const esInfonavit = gastos.esInfonavit;
    const recursosTotales = fueraDeRango ? null
      : (esInfonavit ? m.creditoSolicitado + gastos.ssvAlFrente + gastos.creditoInfonavit : m.creditoSolicitado);
    const enganche = [4, 5].includes(tipo.id) || recursosTotales === null ? 0 : m.valorVivienda - recursosTotales;
    const inversionCliente = tipo.id === 6 ? gastos.total : enganche + gastos.total;

    const fecha = leerFecha(entrada.fecha);
    const primerPago = fechaPrimerPago(fecha);
    const tasas = tasasPorPeriodo(cond);
    const valorDanios = num(entrada.valorDestructible) > 0 ? entrada.valorDestructible : m.valorVivienda;

    const ctx = {
      primerPago, valorDanios,
      segurosExternos: entrada.segurosExternos === 1,
      tipo: tipo.id,
      reduccion: entrada.reduccion,
      tipoComision: entrada.tipoComision,
      comisionPrepago: tipo.comisionPrepago,
      sueldoCotizacion: num(entrada.sueldoCotizacion),
      prepagos: entrada.prepagos || {}
    };

    const sombra = corridaCAT(montoCredito, cond, tasas, ctx);
    const tabla = tablaAmortizacion(montoCredito, cond, tasas, sombra, ctx);

    const costoInicialCAT = gastos.avaluo + gastos.comision;
    const flujos = [costoInicialCAT - sombra[0].saldo].concat(sombra.map((f) => f.flujo));
    const tirMensual = tir(flujos);
    const cat = tirMensual === null ? 0 : Math.pow(1 + tirMensual, 12) - 1;

    const primera = tabla.filas[0];
    const mensualidad = fueraDeRango ? null : primera.erogacion + primera.seguroVida + primera.seguroDanios;

    const mancomunado = (m.ssvConyugeCofinavit > 0 || m.creditoInfConyuge > 0) ? 2
      : (tipo.id === 7 && m.ssvConyugeCICB > 0 ? 2 : 1);
    const claveContrato = `${tipo.id}-${entrada.producto}-${mancomunado}`;
    const contrato = P.CONTRATOS.find((c) => c.clave === claveContrato);
    const etiquetaPlazo = cond.esValora && cond.plazo.anios === 7 ? '' : `${cond.plazo.anios} años`;

    return {
      tipo, cond, aforo, comisionApertura, montos: m,
      financiados, montoConFinanciados, montoCredito, gastos,
      porcentajeFinanciamiento, fueraDeRango, recursosTotales, enganche, inversionCliente,
      ingresoMinimo: ingresoMinimoRequerido(entrada, tipo, cond, m.creditoSolicitado),
      avisos: mensajes(entrada, tipo, m, cond, tipo),
      primerPago, tasas, sombra, tabla, flujos, tirMensual, cat, mensualidad,
      montoMaximoPolitica: entrada.indiceTasa === 5 ? P.MONTO_MAXIMO_POLITICA.indiceR : P.MONTO_MAXIMO_POLITICA.general,
      caratula: {
        producto: `${tipo.comercial} ${cond.esValora ? 'VALORA' : 'PAGOS OPORTUNOS'} ${etiquetaPlazo}`,
        cat,
        tasa: num(entrada.dato) === 0 ? 0 : cond.tasa,
        monto: montoCredito,
        totalPagar: tabla.totales.pagoMensual,
        plazo: etiquetaPlazo,
        comision: gastos.comision,
        penalizacionPrepago: entrada.tipoComision === 1 ? 0 : 0.03,
        penalizacionTardio: claveContrato === '7-2-2' ? P.PENALIZACION_PAGO_TARDIO.cicbConyugalPO : P.PENALIZACION_PAGO_TARDIO.general,
        claveContrato,
        contrato: vacio(entrada.dato) || entrada.dato === 0 ? '' : (contrato ? contrato.nombre : 'Revisa los datos ingresados')
      }
    };
  }

  const MOTOR = { cotizar, condicionesFinancieras, tir, buscarAvaluo, fechaPrimerPago };
  if (typeof module !== 'undefined' && module.exports) module.exports = MOTOR;
  else raiz.MOTOR = MOTOR;
})(this);
