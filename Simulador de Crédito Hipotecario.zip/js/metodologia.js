(function (raiz) {
  'use strict';

  const P = raiz.PARAMETROS;
  const F = raiz.FORMATO;

  const mi = (x) => `<mi>${x}</mi>`;
  const mn = (x) => `<mn>${x}</mn>`;
  const mo = (x) => `<mo>${x}</mo>`;
  const mt = (x) => `<mtext>${x}</mtext>`;
  const sub = (a, b) => `<msub>${a}${b}</msub>`;
  const sup = (a, b) => `<msup>${a}${b}</msup>`;
  const subsup = (a, b, c) => `<msubsup>${a}${b}${c}</msubsup>`;
  const frac = (a, b) => `<mfrac><mrow>${a}</mrow><mrow>${b}</mrow></mfrac>`;
  const par = (x) => `<mrow><mo>(</mo>${x}<mo>)</mo></mrow>`;
  const fila = (...xs) => `<mrow>${xs.join('')}</mrow>`;
  const ec = (...xs) => `<math display="block">${fila(...xs)}</math>`;
  const en = (...xs) => `<math>${fila(...xs)}</math>`;
  const anualidad = (n, tasa) => `<msub><mi>a</mi><mrow><menclose notation="actuarial">${n}</menclose>${tasa || ''}</mrow></msub>`;

  const k = mi('k');
  const km1 = fila(mi('k'), mo('−'), mn('1'));
  const B = (i) => sub(mi('B'), i);
  const E = (i) => sub(mi('E'), i);
  const I = (i) => sub(mi('I'), i);
  const A = (i) => sub(mi('A'), i);
  const X = (i) => sub(mi('X'), i);
  const d = (i) => sub(mi('d'), i);

  const $ = (x) => F.moneda(x);
  const pct = (x, n = 2) => F.porcentaje(x, n);
  const num = (x, n = 6) => (Number.isFinite(x) ? x.toFixed(n) : '—');

  let contador = 0;

  function bloque(titulo, tema, cuerpo) {
    contador += 1;
    return `<section class="metodo">
      <header class="metodo__cabeza"><span class="metodo__numero">${contador}</span><div><h3>${titulo}</h3><p class="metodo__tema">${tema}</p></div></header>
      ${cuerpo}
    </section>`;
  }

  function ejemplo(contenido) {
    return `<div class="ejemplo"><p class="ejemplo__titulo">Con los datos de esta cotización</p>${contenido}</div>`;
  }

  function seccionMonto(r, entrada) {
    const m = r.montos;
    const modo = entrada.modoCalculo;
    let calculo;
    if (modo === 1) {
      calculo = ec(mi('C'), mo('='), mi('V'), mo('·'), mi('LTV'), mo('='), mn($(m.dato)), mo('×'), mn(pct(r.aforo)), mo('='), mn($(m.dato * r.aforo)));
    } else if (modo === 2) {
      calculo = ec(mi('C'), mo('='), frac(fila(mt('Ingreso'), mo('·'), mi('PTI')), fila(mi('ppm'), mo('/'), mn('1000'))), mo('='),
        frac(fila(mn($(m.dato)), mo('×'), mn(pct(r.tipo.pti))), fila(mn(F.numero(r.cond.ppm)), mo('/'), mn('1000'))), mo('='), mn($(m.dato * r.tipo.pti / (r.cond.ppm / 1000))));
    } else {
      calculo = ec(mi('V'), mo('='), frac(mi('C'), mi('LTV')), mo('='), frac(mn($(m.dato)), mn(pct(r.aforo))), mo('='), mn($(m.valorVivienda)));
    }
    return bloque('Monto del crédito y valor de la vivienda', 'Aforo (LTV) y capacidad de pago (PTI)', `
      <p>El crédito se obtiene de una de tres formas. A partir del valor de la vivienda se aplica el aforo; a partir del ingreso, la mensualidad máxima es el ingreso por el PTI y se convierte a crédito con el pago al millar; a partir del monto, el valor de la vivienda se despeja del aforo.</p>
      ${ec(mi('C'), mo('='), mi('V'), mo('·'), mi('LTV'), mspace(), mi('C'), mo('='), frac(fila(mt('Ingreso'), mo('·'), mi('PTI')), fila(mi('ppm'), mo('/'), mn('1000'))), mspace(), mi('V'), mo('='), frac(mi('C'), mi('LTV')))}
      ${ejemplo(calculo + `<p>Aforo aplicado: ${pct(r.aforo)} · PTI: ${pct(r.tipo.pti, 0)} · Crédito máximo: <strong>${$(m.creditoMaximo)}</strong></p>`)}
    `);
  }

  function mspace() {
    return '<mspace width="2em"/>';
  }

  function seccionInteres(r) {
    const f = r.tabla.filas[0];
    const tasa = r.cond.tasa;
    const j = tasa * f.dias / P.DIAS_ANIO_COMERCIAL;
    const diasPromedio = 365.25 / 12;
    const jProm = tasa * diasPromedio / P.DIAS_ANIO_COMERCIAL;
    const efectiva = Math.pow(1 + jProm, 12) - 1;
    return bloque('Interés de cada periodo', 'Tasa nominal, tasa efectiva del periodo y año comercial de 360 días', `
      <p>La tasa anual <em>i</em> es nominal y se aplica con año comercial de 360 días sobre los días reales <em>d<sub>k</sub></em> del mes de cada pago. La tasa efectiva del periodo cambia de un mes a otro: es mayor en un mes de 31 días que en febrero.</p>
      ${ec(sub(mi('j'), k), mo('='), frac(mi('i'), mn('360')), mo('·'), d(k), mspace(), I(k), mo('='), B(km1), mo('·'), sub(mi('j'), k))}
      <p>Con un mes promedio de 365.25/12 días, la tasa efectiva anual equivalente es</p>
      ${ec(sub(mi('i'), mt('ef')), mo('='), sup(par(fila(mn('1'), mo('+'), frac(fila(mi('i'), mo('·'), mn('30.4375')), mn('360')))), mn('12')), mo('−'), mn('1'))}
      ${ejemplo(`
        ${ec(sub(mi('j'), mn('1')), mo('='), frac(mn(pct(tasa)), mn('360')), mo('×'), mn(f.dias), mo('='), mn(pct(j, 4)))}
        ${ec(I(mn('1')), mo('='), mn($(f.saldo)), mo('×'), mn(pct(j, 4)), mo('='), mn($(f.interes)))}
        <p>Tasa efectiva anual equivalente: <strong>${pct(efectiva)}</strong> contra una tasa nominal de ${pct(tasa)}.</p>`)}
    `);
  }

  function seccionPagoMillar(r) {
    const tasa = r.cond.tasa;
    const n = r.cond.plazo.meses;
    const j = tasa * (365.25 / 12) / P.DIAS_ANIO_COMERCIAL;
    const teorico = 1000 * j / (1 - Math.pow(1 + j, -n));
    const C = r.montoCredito;
    return bloque('Pago al millar y la anualidad', 'Valor presente de una anualidad vencida', `
      <p>La primera erogación sale del <strong>pago al millar</strong> (ppm), la mensualidad por cada $1,000 de crédito. Es el recíproco del valor presente de una anualidad vencida de <em>n</em> pagos a la tasa del periodo:</p>
      ${ec(mi('ppm'), mo('≈'), frac(mn('1000'), anualidad(mi('n'), mi('j'))), mo('='), frac(fila(mn('1000'), mo('·'), mi('j')), fila(mn('1'), mo('−'), sup(mi('v'), mi('n')))), mspace(), mi('v'), mo('='), frac(mn('1'), fila(mn('1'), mo('+'), mi('j'))))}
      ${ec(E(mn('1')), mo('='), mi('C'), mo('·'), frac(mi('ppm'), mn('1000')))}
      <p>La tabla de precios fija el ppm con dos decimales; el valor teórico sirve para comprobar que es consistente con la tasa y el plazo.</p>
      ${ejemplo(`
        ${ec(E(mn('1')), mo('='), mn($(C)), mo('×'), frac(mn(F.numero(r.cond.ppm)), mn('1000')), mo('='), mn($(r.tabla.filas[0].erogacion)))}
        <p>Con <em>j</em> = ${pct(j, 4)} y <em>n</em> = ${n} meses, el ppm teórico es <strong>${F.numero(teorico)}</strong>; el ppm de la tabla es <strong>${F.numero(r.cond.ppm)}</strong>.</p>`)}
    `);
  }

  function seccionAmortizacion(r) {
    const f = r.tabla.filas[0];
    return bloque('Tabla de amortización', 'Interés, amortización y saldo insoluto', `
      <p>Cada erogación se divide en interés y abono a capital. El saldo se actualiza restando la amortización y el anticipo a capital, sumando la penalización por anticipo y restando la aportación patronal del Infonavit cuando aplica.</p>
      ${ec(A(k), mo('='), E(k), mo('−'), I(k))}
      ${ec(B(k), mo('='), B(km1), mo('−'), A(k), mo('−'), X(k), mo('+'), sub(mi('Pen'), k), mo('−'), sub(mi('Apo'), k))}
      <p>En el último periodo la erogación se ajusta para liquidar exactamente el saldo: si <math>${fila(B(km1), mo('+'), I(k), mo('≤'), E(km1))}</math>, entonces <math>${fila(E(k), mo('='), B(km1), mo('+'), I(k))}</math>.</p>
      <p>El saldo de la tabla coincide con el enfoque prospectivo: en cada fecha es el valor presente de los pagos que faltan, descontados con las tasas de los periodos futuros.</p>
      ${ejemplo(`
        ${ec(A(mn('1')), mo('='), mn($(f.erogacion)), mo('−'), mn($(f.interes)), mo('='), mn($(f.amortizacion)))}
        ${ec(B(mn('1')), mo('='), mn($(f.saldo)), mo('−'), mn($(f.amortizacion)), mo('='), mn($(f.saldoFinal)))}`)}
    `);
  }

  function seccionProducto(r) {
    const cond = r.cond;
    if (cond.esValora) {
      const e1 = r.tabla.filas[0].erogacion;
      const e13 = r.tabla.filas[12] ? r.tabla.filas[12].erogacion : null;
      return bloque('Valora: pagos crecientes y tasa que baja', 'Anualidad creciente en progresión geométrica', `
        <p>La erogación se mantiene fija durante cada año y crece en una proporción <em>g</em> al iniciar el siguiente (meses 13, 25, 37, …). Año con año forma una anualidad geométrica:</p>
        ${ec(E(fila(mi('t'), mo(','), mi('m'))), mo('='), E(mn('1')), mo('·'), sup(par(fila(mn('1'), mo('+'), mi('g'))), fila(mi('t'), mo('−'), mn('1'))), mspace(), mi('t'), mo('='), mn('1'), mo(','), mo('…'), mo(','), mi('n'), mo('/'), mn('12'))}
        <p>Además, por pago puntual la tasa baja ${pct(P.AJUSTES_TASA.valora.reduccion)} cada año a partir del mes ${P.AJUSTES_TASA.valora.desdeMes} hasta llegar a la tasa piso de ${pct(cond.piso)}.</p>
        ${ec(sub(mi('i'), mi('t')), mo('='), mi('max'), par(fila(sub(mi('i'), fila(mi('t'), mo('−'), mn('1'))), mo('−'), mn('0.25%'), mo(','), sub(mi('i'), mt('piso')))))}
        ${ejemplo(`<p>Incremento anual <em>g</em> = ${pct(cond.incremento, 1)}. Erogación del año 1: ${$(e1)}; del año 2: ${$(e13)} = ${$(e1)} × (1 + ${pct(cond.incremento, 1)}).</p>`)}
      `);
    }
    const ajustes = Object.entries(P.AJUSTES_TASA.pagosOportunos).map(([mes, baja]) => `mes ${mes}: −${pct(baja)}`).join(' · ');
    const tasas = [1, 13, 25, 37, 49].map((mes) => `${pct(r.tasas[mes])}`).join(' → ');
    return bloque('Pagos Oportunos: pago fijo y tasa que baja', 'Anualidad vencida nivelada', `
      <p>La erogación se mantiene constante durante todo el crédito. Por pago puntual la tasa disminuye en fechas fijas (${ajustes}). Como la erogación no cambia, una mayor parte de cada pago se va a capital y el crédito se liquida antes del plazo contratado.</p>
      ${ec(E(k), mo('='), E(mn('1')), mspace(), sub(mi('i'), k), mo('='), sub(mi('i'), mn('1')), mo('−'), munder(mo('∑'), fila(mi('m'), mo('≤'), mi('k'))), sub(mi('Δ'), mi('m')))}
      ${ejemplo(`<p>Tasas aplicadas en los meses 1, 13, 25, 37 y 49: ${tasas}. El crédito se liquida en ${r.tabla.liquidaAnios} años ${r.tabla.liquidaMeses} meses en lugar de ${cond.plazo.anios} años.</p>`)}
    `);
  }

  function munder(a, b) {
    return `<munder>${a}${b}</munder>`;
  }

  function seccionSeguros(r, entrada) {
    const f = r.tabla.filas[0];
    const valorDanios = entrada.valorDestructible > 0 ? entrada.valorDestructible : r.montos.valorVivienda;
    return bloque('Seguros y pago mensual', 'Cargos que se suman a la erogación', `
      <p>El seguro de vida y desempleo se calcula sobre el saldo inicial de cada periodo; el seguro de daños, sobre el valor destructible (o el valor de la vivienda si no se captura).</p>
      ${ec(subsup(mi('S'), k, mi('v')), mo('='), B(km1), mo('·'), mn(pct(P.SEGUROS.vidaDesempleo, 2)), mspace(), subsup(mi('S'), k, mi('d')), mo('='), mi('VD'), mo('·'), mn(pct(P.SEGUROS.danios, 3)))}
      ${ec(sub(mi('Pago'), k), mo('='), E(k), mo('+'), X(k), mo('+'), subsup(mi('S'), k, mi('v')), mo('+'), subsup(mi('S'), k, mi('d')))}
      ${ejemplo(entrada.segurosExternos === 1
        ? '<p>El cliente contrata seguros externos, así que los seguros no se cargan en la corrida.</p>'
        : `${ec(sub(mi('Pago'), mn('1')), mo('='), mn($(f.erogacion)), mo('+'), mn($(f.seguroVida)), mo('+'), mn($(f.seguroDanios)), mo('='), mn($(f.pagoMensual)))}
          <p>Valor destructible usado: ${$(valorDanios)}.</p>`)}
    `);
  }

  function seccionPrepagos(r) {
    return bloque('Anticipos a capital', 'Recalcular el plazo o la mensualidad', `
      <p>Un anticipo <em>X<sub>k</sub></em> reduce el saldo. Si el tipo de comisión es «Pago anticipado», se cobra una penalización con IVA que se suma al saldo:</p>
      ${ec(sub(mi('Pen'), k), mo('='), X(k), mo('·'), sub(mi('c'), mi('p')), mo('·'), par(fila(mn('1'), mo('+'), mn(pct(P.IVA, 0)))))}
      <p>Con «Disminuir plazo» la erogación sigue igual y el crédito termina antes. Con «Disminuir pago» la erogación se recalcula con la proporción erogación/saldo de la corrida sin anticipos:</p>
      ${ec(E(k), mo('='), B(km1), mo('·'), frac(subsup(mi('E'), k, mo('′')), subsup(mi('B'), km1, mo('′'))))}
      <p>Penalización vigente: ${pct(r.tipo.comisionPrepago, 0)} del anticipo, más IVA, solo con comisión «Pago anticipado».</p>
    `);
  }

  function seccionGastos(r) {
    const g = r.gastos;
    return bloque('Gastos de originación', 'Desembolsos al firmar', `
      <p>Los impuestos y derechos y los honorarios notariales son un porcentaje del valor de la vivienda. El avalúo sale de una tabla por rango de valor y la comisión por contratación es un porcentaje del crédito solicitado.</p>
      ${ec(mi('G'), mo('='), mi('V'), mo('·'), par(fila(mn('3%'), mo('+'), mn('2%'))), mo('+'), mt('Avalúo'), par(mi('V')), mo('+'), mi('C'), mo('·'), sub(mi('c'), mi('a')))}
      ${ejemplo(`<p>Impuestos ${$(g.impuestos)} + honorarios ${$(g.honorarios)} + avalúo ${$(g.avaluo)} + comisión ${$(g.comision)}${g.infonavitOriginacion ? ` + originación Infonavit ${$(g.infonavitOriginacion)}` : ''}${r.financiados ? ` − gastos financiados ${$(r.financiados)}` : ''} = <strong>${$(g.total)}</strong>.</p>`)}
    `);
  }

  function seccionCAT(r) {
    const costo = r.gastos.avaluo + r.gastos.comision;
    const C = r.sombra[0].saldo;
    return bloque('Costo Anual Total (CAT)', 'Ecuación de valor con fecha focal en la firma', `
      <p>El CAT es la tasa que iguala lo que el cliente recibe con lo que paga. En la fecha focal 0 se plantea la ecuación de valor: el crédito menos la comisión y el avalúo es igual al valor presente de las erogaciones más los seguros, sin anticipos y con pago puntual. La tasa mensual <em>r</em> que la resuelve (TIR) se convierte en tasa efectiva anual.</p>
      ${ec(mi('C'), mo('−'), par(fila(mi('Com'), mo('+'), mi('Av'))), mo('='), munderover(mo('∑'), fila(mi('k'), mo('='), mn('1')), mi('n')), frac(fila(E(k), mo('+'), sub(mi('S'), k)), sup(par(fila(mn('1'), mo('+'), mi('r'))), mi('k'))))}
      ${ec(mi('CAT'), mo('='), sup(par(fila(mn('1'), mo('+'), mi('r'))), mn('12')), mo('−'), mn('1'))}
      <p>La ecuación se resuelve con el método de Newton-Raphson partiendo de <em>r</em> = 0.</p>
      ${ejemplo(`
        ${ec(mn($(C)), mo('−'), mn($(costo)), mo('='), mn($(C - costo)))}
        <p>TIR mensual <em>r</em> = ${num(r.tirMensual, 8)} → CAT = (1 + r)<sup>12</sup> − 1 = <strong>${pct(r.cat, 4)}</strong>.</p>`)}
    `);
  }

  function munderover(a, b, c) {
    return `<munderover>${a}${b}${c}</munderover>`;
  }

  function seccionIngreso(r) {
    return bloque('Ingreso mínimo requerido', 'Capacidad de pago', `
      <p>El ingreso mensual mínimo es el mayor entre el mínimo del producto y el que hace que la mensualidad (sin seguros) no rebase el PTI.</p>
      ${ec(mt('Ingreso mín.'), mo('='), mi('max'), par(fila(mt('mínimo del producto'), mo(','), frac(fila(mi('C'), mo('·'), mi('ppm'), mo('/'), mn('1000')), mi('PTI')))))}
      ${ejemplo(`<p>max(${$(r.tipo.ingresoMinimo)}, …) = <strong>${$(r.ingresoMinimo)}</strong></p>`)}
    `);
  }

  function seccionInfonavit(r) {
    if (![2, 5].includes(r.tipo.id)) return '';
    const I = P.INFONAVIT;
    const tope = I.uma * I.topeVecesUma * I.aportacionPatronal * I.diasBimestre;
    return bloque('Aportación patronal Infonavit', 'Pagos bimestrales que reducen el saldo', `
      <p>En los créditos con apoyo Infonavit, la aportación patronal de 5% del salario se abona a capital cada bimestre, con tope de 25 UMA diarias y un incremento anual de 3%.</p>
      ${ec(mi('Apo'), mo('='), mi('min'), par(fila(mi('Sueldo'), mo('·'), mn('5%'), mo('·'), mn('2'), mo(','), mn(F.numero(I.uma)), mo('·'), mn('25'), mo('·'), mn('5%'), mo('·'), mn('60.8'))))}
      <p>Tope bimestral: ${$(tope)}.</p>
    `);
  }

  function tablaPrecios(r) {
    const c = r.cond.campana;
    const filasValora = c.valora.map((v, i) => `<tr><th scope="row">${P.INDICES_RIESGO[i]}</th><td>${pct(v.tasa)}</td><td>${F.numero(v.ppm[10])}</td><td>${F.numero(v.ppm[15])}</td><td>${F.numero(v.ppm[20])}</td><td>${pct(v.incremento, 1)}</td></tr>`).join('');
    const filasPO = Object.entries(c.pagosOportunos).map(([anios, v]) => `<tr><th scope="row">${anios} años</th><td>${pct(v.tasa)}</td><td>${F.numero(v.ppm)}</td></tr>`).join('');
    const filasTipos = P.TIPOS_CREDITO.map((t) => `<tr><th scope="row">${t.nombre}</th><td>${pct(t.comisionApertura)}</td><td>${pct(t.comisionPrepago, 0)}</td><td>${$(t.ingresoMinimo)}</td><td>${$(t.creditoMinimo)}</td><td>${$(t.valorMinimo)}</td><td>${pct(t.pti, 0)}</td></tr>`).join('');
    return bloque('Parámetros', `Campaña «${c.nombre}» y tipos de crédito`, `
      <div class="tablas-parametros">
        <div class="tabla-envoltura"><table class="tabla tabla--compacta"><caption>Valora · piso ${pct(c.piso)} · techo ${pct(c.techo)}</caption>
          <thead><tr><th scope="col">Índice</th><th scope="col">Tasa</th><th scope="col">ppm 10</th><th scope="col">ppm 15</th><th scope="col">ppm 20</th><th scope="col">Inc. anual</th></tr></thead><tbody>${filasValora}</tbody></table></div>
        <div class="tabla-envoltura"><table class="tabla tabla--compacta"><caption>Pagos Oportunos</caption>
          <thead><tr><th scope="col">Plazo</th><th scope="col">Tasa</th><th scope="col">ppm</th></tr></thead><tbody>${filasPO}</tbody></table></div>
      </div>
      <div class="tabla-envoltura"><table class="tabla tabla--compacta"><caption>Tipos de crédito</caption>
        <thead><tr><th scope="col">Tipo</th><th scope="col">Comisión apertura</th><th scope="col">Penalización anticipo</th><th scope="col">Ingreso mín.</th><th scope="col">Crédito mín.</th><th scope="col">Valor mín.</th><th scope="col">PTI</th></tr></thead><tbody>${filasTipos}</tbody></table></div>
    `);
  }

  function seccionNotas() {
    return bloque('Notas sobre la réplica', 'Diferencias del simulador de referencia que se conservaron', `
      <ul class="lista-notas">
        <li>El aforo por monto de crédito (95%, 70%, 65%, …) del simulador de referencia compara contra una celda que siempre está vacía, de modo que siempre aplica el aforo del primer rango. Se replicó igual para obtener los mismos resultados.</li>
        <li>La campaña «Hipoteca Green» exenta la comisión por contratación pero sí cobra avalúo; «WM» y «Premium» exentan ambos.</li>
        <li>En el modo «Monto de crédito», el aviso de ingresos mínimos compara el monto capturado contra el ingreso mínimo, igual que en la referencia.</li>
        <li>El CAT se calcula sin anticipos, sin aportaciones Infonavit y sin IVA, con la comisión por contratación y el avalúo como costos iniciales.</li>
      </ul>
    `);
  }

  function generar(r, entrada) {
    if (!r.cond.valida || !(r.montoCredito > 0)) {
      return '<p class="vacio">Captura un monto y una combinación válida de producto, plazo y tasa para ver la metodología con tus datos.</p>';
    }
    contador = 0;
    return [
      `<p class="introduccion">Notación: <em>C</em> crédito, <em>V</em> valor de la vivienda, <em>i</em> tasa anual nominal, <em>d<sub>k</sub></em> días del periodo <em>k</em>, <em>B<sub>k</sub></em> saldo insoluto, <em>E<sub>k</sub></em> erogación, <em>I<sub>k</sub></em> interés, <em>A<sub>k</sub></em> amortización y <em>X<sub>k</sub></em> anticipo a capital.</p>`,
      seccionMonto(r, entrada), seccionInteres(r), seccionPagoMillar(r), seccionAmortizacion(r), seccionProducto(r),
      seccionSeguros(r, entrada), seccionPrepagos(r), seccionGastos(r), seccionCAT(r), seccionIngreso(r), seccionInfonavit(r),
      tablaPrecios(r), seccionNotas()
    ].join('');
  }

  raiz.METODOLOGIA = { generar, en };
})(this);
