(function () {
  'use strict';

  const P = window.PARAMETROS;
  const M = window.MOTOR;
  const F = window.FORMATO;

  const $ = (id) => document.getElementById(id);
  const VISTAS = ['cotizacion', 'tabla', 'caratula', 'metodologia'];

  const VALORES_INICIALES = {
    tipoCredito: 1, producto: 2, plazo: 4, indiceTasa: 1, campana: 5, actividad: 1,
    modoCalculo: 1, tipoComision: 1, reduccion: 1, dato: 2000000
  };

  const estado = {
    producto: VALORES_INICIALES.producto,
    modoCalculo: VALORES_INICIALES.modoCalculo,
    prepagos: {},
    resultado: null,
    entrada: null
  };

  const CAMPOS_MONEDA = ['dato', 'creditoSolicitado', 'valorDestructible', 'sueldoCotizacion', 'ssvTitular',
    'creditoInfonavitTitular', 'ssvConyugeCofinavit', 'creditoInfonavitConyuge', 'ssvTitularCICB', 'ssvConyugeCICB'];
  const CAMPOS_PORCENTAJE = ['comisionManual', 'impuestosManual', 'honorariosManual'];

  function llenarSelect(select, opciones) {
    const actual = select.value;
    select.innerHTML = opciones.map((o) => `<option value="${o.valor}">${o.texto}</option>`).join('');
    if (opciones.some((o) => String(o.valor) === actual)) select.value = actual;
  }

  function opcionesDependientes() {
    const tipo = Number($('tipoCredito').value) || VALORES_INICIALES.tipoCredito;
    const esValora = estado.producto === 1;
    const campana = P.CAMPANAS[(Number($('campana').value) || VALORES_INICIALES.campana) - 1];

    llenarSelect($('plazo'), P.PLAZOS.map((p) => ({
      valor: p.id,
      texto: esValora && p.anios === 7 ? '— (no disponible en Valora)' : `${p.anios} años`
    })));

    const plazo = P.PLAZOS[(Number($('plazo').value) || VALORES_INICIALES.plazo) - 1];
    const cond = M.condicionesFinancieras({
      campana: campana.id, plazo: plazo.id, producto: estado.producto, indiceTasa: 1
    });
    llenarSelect($('indiceTasa'), P.INDICES_RIESGO.map((ir, i) => ({
      valor: i + 1,
      texto: `IR ${ir} · ${cond.opcionesTasa[i] === null ? 'sin tasa' : F.porcentaje(cond.opcionesTasa[i])}`
    })));

    llenarSelect($('campana'), P.CAMPANAS.map((c) => ({
      valor: c.id,
      texto: c.soloTipo && c.soloTipo !== tipo ? `${c.nombre} (solo Adquisición Tradicional)` : c.nombre
    })));

    llenarSelect($('actividad'), [
      { valor: 1, texto: tipo === 7 ? '—' : 'Empleado' },
      { valor: 2, texto: [2, 3, 5].includes(tipo) ? '—' : 'Independiente' }
    ]);

    llenarSelect($('tipoComision'), [
      { valor: 1, texto: 'Contratación - crédito' },
      { valor: 2, texto: [2, 3, 5].includes(tipo) ? '—' : 'Pago anticipado' }
    ]);

    document.querySelectorAll('[data-solo]').forEach((el) => {
      el.hidden = !el.dataset.solo.split(',').map(Number).includes(tipo);
    });

    const etiquetas = { 1: 'Valor de la vivienda', 2: 'Ingresos mensuales', 3: 'Monto de crédito' };
    $('datoEtiqueta').textContent = etiquetas[estado.modoCalculo];
  }

  function leer(id) {
    const el = $(id);
    if (!el || el.closest('[hidden]')) return null;
    if (CAMPOS_MONEDA.includes(id)) return F.leerMonto(el.value);
    if (CAMPOS_PORCENTAJE.includes(id)) {
      const v = F.leerMonto(el.value);
      return v === null ? null : v / 100;
    }
    return el.value;
  }

  function construirEntrada() {
    const tipo = Number($('tipoCredito').value);
    return {
      fecha: $('fecha').value || F.hoyISO(),
      tipoCredito: tipo,
      producto: estado.producto,
      plazo: Number($('plazo').value),
      indiceTasa: Number($('indiceTasa').value),
      campana: Number($('campana').value),
      actividad: Number($('actividad').value),
      modoCalculo: estado.modoCalculo,
      tipoComision: Number($('tipoComision').value),
      segurosExternos: $('segurosExternos').checked ? 1 : 2,
      reduccion: Number($('reduccion').value),
      dato: leer('dato'),
      creditoSolicitado: leer('creditoSolicitado'),
      valorDestructible: leer('valorDestructible'),
      sueldoCotizacion: leer('sueldoCotizacion'),
      gastosFinanciados: leer('gastosFinanciados') || 'SI',
      comisionManual: leer('comisionManual'),
      impuestosManual: leer('impuestosManual'),
      honorariosManual: leer('honorariosManual'),
      ssvTitular: tipo === 7 ? leer('ssvTitularCICB') : leer('ssvTitular'),
      creditoInfonavitTitular: leer('creditoInfonavitTitular'),
      ssvConyugeCofinavit: leer('ssvConyugeCofinavit'),
      creditoInfonavitConyuge: leer('creditoInfonavitConyuge'),
      ssvConyugeCICB: leer('ssvConyugeCICB'),
      prepagos: estado.prepagos
    };
  }

  function duracion(anios, meses) {
    const a = `${anios} ${anios === 1 ? 'año' : 'años'}`;
    if (!meses) return a;
    return `${a} ${meses} ${meses === 1 ? 'mes' : 'meses'}`;
  }

  function fila(etiqueta, valor, clase = '') {
    return `<div class="lista-valores__fila ${clase}"><dt>${etiqueta}</dt><dd>${valor}</dd></div>`;
  }

  function pintarAvisos(r, entrada) {
    const avisos = [];
    if (r.avisos.combinacion) avisos.push(['critico', r.avisos.combinacion]);
    if (r.avisos.dato) avisos.push(['alerta', r.avisos.dato]);
    if (r.avisos.credito) avisos.push(['critico', r.avisos.credito]);
    if (r.montos.creditoSolicitado > 0 && r.montos.creditoSolicitado < r.tipo.creditoMinimo) {
      avisos.push(['alerta', `El crédito mínimo es ${F.moneda(r.tipo.creditoMinimo)}`]);
    }
    if (r.avisos.linea) avisos.push(['info', r.avisos.linea]);
    if (r.gastos.cotizarAvaluo) avisos.push(['info', 'Avalúo: favor de cotizar, el importe es aproximado']);
    if (r.enganche < 0) avisos.push(['info', 'El enganche negativo significa remanente para el cliente']);
    const campana = P.CAMPANAS[entrada.campana - 1];
    if (campana.soloTipo && campana.soloTipo !== entrada.tipoCredito) {
      avisos.push(['info', `La campaña ${campana.nombre} aplica solo para Adquisición Tradicional`]);
    }
    $('avisos').innerHTML = avisos.map(([tipo, texto]) => `<p class="chip chip--${tipo}">${texto}</p>`).join('');

    $('avisoDato').hidden = !r.avisos.dato;
    $('avisoDato').textContent = r.avisos.dato;
    $('avisoCredito').hidden = !r.avisos.credito;
    $('avisoCredito').textContent = r.avisos.credito;
  }

  function pintarCotizacion(r, entrada) {
    const m = r.montos;
    const cond = r.cond;
    const t = r.tipo;
    const g = r.gastos;
    const esInfonavit = g.esInfonavit;
    const primera = r.tabla.filas[0];

    $('programa').textContent = `${t.nombre} · ${cond.esValora ? 'Valora' : 'Pagos Oportunos'} · ${cond.plazo.anios} años · Campaña ${cond.campana.nombre}`;

    if (r.mensualidad === null) {
      $('rMensualidad').textContent = 'Fuera de rango';
      $('rMensualidadNota').textContent = 'El crédito solicitado supera el máximo';
    } else {
      $('rMensualidad').textContent = F.moneda(r.mensualidad);
      $('rMensualidadNota').textContent = `Erogación ${F.moneda(primera.erogacion)} + seguros ${F.moneda(primera.seguroVida + primera.seguroDanios)}`;
    }
    $('rCAT').textContent = F.porcentaje(r.cat, 1);
    $('rCATNota').textContent = `${F.porcentaje(r.cat, 4)} · sin IVA, informativo`;
    $('rTasa').textContent = F.porcentaje(cond.tasa);
    $('rTasaNota').textContent = cond.esValora
      ? `Fija; baja hasta ${F.porcentaje(cond.piso)} por pago puntual`
      : `Fija; baja a ${F.porcentaje(r.tasas[49])} por pago puntual`;
    const liquida = r.tabla.liquidaPeriodo === null ? '—' : duracion(r.tabla.liquidaAnios, r.tabla.liquidaMeses);
    $('rLiquida').textContent = liquida;

    const recursos = [
      fila('Valor de la vivienda', F.moneda(m.valorVivienda)),
      fila(t.id === 7 ? '% de financiamiento CI+CB' : '% de financiamiento', F.porcentaje(r.porcentajeFinanciamiento, 1)),
      fila('Crédito máximo posible', F.moneda(m.creditoMaximo)),
      fila('Crédito solicitado', F.moneda(m.creditoSolicitado))
    ];
    if (r.financiados !== null) {
      recursos.push(fila('Gastos notariales financiados', F.moneda(r.financiados)));
      if (r.montoConFinanciados !== null) recursos.push(fila('Monto máximo pago de pasivo + gastos financiados', F.moneda(r.montoConFinanciados)));
    }
    if (esInfonavit) {
      recursos.push(fila('Subcuenta de vivienda', F.moneda(g.ssvAlFrente)));
      recursos.push(fila('Crédito Infonavit', F.moneda(g.creditoInfonavit)));
    }
    recursos.push(fila(esInfonavit ? 'Recursos totales' : 'Crédito banco',
      r.recursosTotales === null ? 'Fuera de rango' : F.moneda(r.recursosTotales), 'lista-valores__fila--total'));
    if (t.id !== 6) {
      const etiqueta = [4, 5].includes(t.id) ? 'Desembolso'
        : (r.recursosTotales !== null && r.recursosTotales - m.valorVivienda > 0 ? 'Monto remanente' : 'Enganche para la compra');
      recursos.push(fila(etiqueta, F.moneda(r.enganche)));
    }
    recursos.push(fila('Gastos de originación', F.moneda(g.total)));
    recursos.push(fila('Inversión del cliente', F.moneda(r.inversionCliente), 'lista-valores__fila--total'));
    $('listaRecursos').innerHTML = recursos.join('');

    const pctTexto = (manual, calculado) => (manual === null ? F.porcentaje(calculado, 1) : F.porcentaje(manual, 2));
    const gastos = [];
    if (esInfonavit) gastos.push(fila(`Infonavit gastos de originación · ${F.porcentaje(P.GASTOS.infonavitOriginacion, 0)}`, F.moneda(g.infonavitOriginacion)));
    gastos.push(fila(`${esInfonavit ? 'Infonavit impuestos y derechos' : 'Impuestos y derechos'} · ${pctTexto(entrada.impuestosManual, g.porcentajeImpuestos)}`, F.moneda(g.impuestos)));
    gastos.push(fila(`Honorarios notariales · ${pctTexto(entrada.honorariosManual, g.porcentajeHonorarios)}`, F.moneda(g.honorarios)));
    gastos.push(fila('Avalúo hipotecario', F.moneda(g.avaluo)));
    gastos.push(fila(`Comisión por contratación · ${F.porcentaje(r.comisionApertura)}`, F.moneda(g.comision)));
    if (r.financiados) gastos.push(fila('Menos gastos financiados', `−${F.moneda(r.financiados)}`));
    gastos.push(fila('Total', F.moneda(g.total), 'lista-valores__fila--total'));
    $('listaGastos').innerHTML = gastos.join('');

    $('listaCondiciones').innerHTML = [
      fila('Producto', cond.esValora ? 'Valora' : 'Pagos Oportunos'),
      fila('Plazo', `${cond.plazo.anios} años (${cond.plazo.meses} meses)`),
      fila('Tasa de interés anual', F.porcentaje(cond.tasa)),
      fila('Incremento anual del pago', F.porcentaje(cond.incremento)),
      fila('Pago al millar', cond.ppm === null ? '—' : `${F.numero(cond.ppm)} por cada $1,000`),
      fila('Tasa piso · techo', `${F.porcentaje(cond.piso)} · ${F.porcentaje(cond.techo)}`),
      fila('Ingreso mínimo requerido', F.moneda(r.ingresoMinimo), 'lista-valores__fila--total')
    ].join('');

    $('listaParametros').innerHTML = [
      fila('Crédito mínimo', F.moneda(t.creditoMinimo)),
      fila('Valor mínimo del inmueble', F.moneda(t.valorMinimo)),
      fila('Aforo (LTV)', F.porcentaje(r.aforo, 0)),
      fila('Enganche mínimo', F.porcentaje(r.aforo === 0 ? 0 : 1 - r.aforo, 0)),
      fila('Relación pago/ingreso (PTI)', F.porcentaje(t.pti, 0)),
      fila('Primer pago', F.fechaCorta(r.primerPago.anio, r.primerPago.mes, r.primerPago.dia))
    ].join('');

    if ($('creditoInfonavitCICB')) $('creditoInfonavitCICB').textContent = t.id === 7 ? F.moneda(m.cicb.creditoInfonavit) : '—';

    const obs = [];
    if (m.valorVivienda) {
      obs.push(`Los impuestos y derechos están calculados al ${F.porcentaje(g.impuestos / m.valorVivienda)} del valor del inmueble; pueden cambiar según la entidad federativa.`);
      obs.push(`Los honorarios notariales están calculados al ${F.porcentaje(g.honorarios / m.valorVivienda)} del valor del inmueble; pueden variar según la entidad federativa.`);
    }
    obs.push('El crédito solicitado depende de la capacidad de pago de cada cliente.');
    obs.push('La penalización por pago anticipado, cuando aplica, causa IVA; la tabla de amortización ya lo incluye.');
    obs.push('La tabla supone que cada pago se hace puntualmente. Para Pagos Oportunos y Valora deben cumplirse las reglas del programa para que baje la tasa.');
    $('observaciones').innerHTML = obs.map((o) => `<li>${o}</li>`).join('');

    pintarGrafica(r);
  }

  function agruparPorAnio(r) {
    const anios = [];
    r.tabla.filas.forEach((f) => {
      if (f.saldo <= 0) return;
      const a = Math.ceil(f.k / 12);
      if (!anios[a - 1]) anios[a - 1] = { anio: a, interes: 0, capital: 0, seguros: 0, saldo: 0 };
      const x = anios[a - 1];
      x.interes += f.interes;
      x.capital += f.amortizacion + f.prepago;
      x.seguros += f.seguroVida + f.seguroDanios;
      x.saldo = Math.max(f.saldoFinal, 0);
    });
    return anios.filter(Boolean);
  }

  function escalaBonita(maximo) {
    if (maximo <= 0) return { tope: 1, paso: 1 };
    const bruto = maximo / 4;
    const potencia = Math.pow(10, Math.floor(Math.log10(bruto)));
    const paso = [1, 2, 2.5, 5, 10].map((f) => f * potencia).find((p) => p >= bruto);
    return { tope: paso * Math.ceil(maximo / paso), paso };
  }

  function compacto(x) {
    if (x >= 1e6) return `$${(x / 1e6).toLocaleString('es-MX', { maximumFractionDigits: 1 })} M`;
    if (x >= 1e3) return `$${(x / 1e3).toLocaleString('es-MX', { maximumFractionDigits: 0 })} mil`;
    return `$${x.toFixed(0)}`;
  }

  function pintarGrafica(r) {
    const datos = agruparPorAnio(r);
    const caja = $('grafica');
    if (!datos.length) {
      caja.innerHTML = '<p class="vacio">Sin pagos que graficar.</p>';
      return;
    }
    const ancho = 520;
    const alto = 230;
    const margen = { izq: 76, der: 10, arr: 12, aba: 28 };
    const w = ancho - margen.izq - margen.der;
    const h = alto - margen.arr - margen.aba;
    const n = datos.length;
    const banda = w / n;
    const barra = Math.max(4, banda * 0.68);

    const totalMax = Math.max(...datos.map((d) => d.interes + d.capital + d.seguros));
    const e1 = escalaBonita(totalMax);
    const y1 = (v) => margen.arr + h - (v / e1.tope) * h;

    const saldoMax = Math.max(r.montoCredito, ...datos.map((d) => d.saldo));
    const e2 = escalaBonita(saldoMax);
    const y2 = (v) => margen.arr + h - (v / e2.tope) * h;

    const lineas = [];
    for (let v = 0; v <= e1.tope + 1e-9; v += e1.paso) {
      lineas.push(`<line class="g-rejilla" x1="${margen.izq}" x2="${ancho - margen.der}" y1="${y1(v)}" y2="${y1(v)}"/>`);
      lineas.push(`<text class="g-eje" x="${margen.izq - 8}" y="${y1(v) + 4}" text-anchor="end">${compacto(v)}</text>`);
    }

    const barras = datos.map((d, i) => {
      const x = margen.izq + i * banda + (banda - barra) / 2;
      const piezas = [['g-interes', d.interes], ['g-capital', d.capital], ['g-seguros', d.seguros]];
      let acumulado = 0;
      const rects = piezas.map(([clase, v]) => {
        const yTop = y1(acumulado + v);
        const alto = y1(acumulado) - yTop;
        acumulado += v;
        return `<rect class="${clase}" x="${x.toFixed(1)}" y="${yTop.toFixed(1)}" width="${barra.toFixed(1)}" height="${Math.max(0, alto).toFixed(1)}"><title>Año ${d.anio}: ${F.moneda(v)}</title></rect>`;
      }).join('');
      return rects;
    }).join('');

    const etiquetasX = datos.map((d, i) => {
      if (n > 12 && d.anio % 2 === 0 && i !== n - 1) return '';
      const x = margen.izq + i * banda + banda / 2;
      return `<text class="g-eje" x="${x.toFixed(1)}" y="${alto - 8}" text-anchor="middle">${d.anio}</text>`;
    }).join('');

    const puntos = [[margen.izq, y2(r.montoCredito)]].concat(datos.map((d, i) => [margen.izq + (i + 1) * banda, y2(d.saldo)]));
    const camino = puntos.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
    const area = `${camino} L${puntos[puntos.length - 1][0].toFixed(1)},${y2(0)} L${margen.izq},${y2(0)} Z`;

    const lineas2 = [];
    for (let v = 0; v <= e2.tope + 1e-9; v += e2.paso) {
      lineas2.push(`<line class="g-rejilla" x1="${margen.izq}" x2="${ancho - margen.der}" y1="${y2(v)}" y2="${y2(v)}"/>`);
      lineas2.push(`<text class="g-eje" x="${margen.izq - 8}" y="${y2(v) + 4}" text-anchor="end">${compacto(v)}</text>`);
    }

    caja.innerHTML = `
      <figure class="grafica__panel">
        <figcaption><span>Pagos por año</span>
          <span class="leyenda"><span><i class="muestra muestra--interes"></i>Interés</span><span><i class="muestra muestra--capital"></i>Capital</span><span><i class="muestra muestra--seguros"></i>Seguros</span></span>
        </figcaption>
        <svg viewBox="0 0 ${ancho} ${alto}" preserveAspectRatio="xMidYMid meet">${lineas.join('')}${barras}${etiquetasX}</svg>
      </figure>
      <figure class="grafica__panel">
        <figcaption><span>Saldo insoluto al cierre de cada año</span></figcaption>
        <svg viewBox="0 0 ${ancho} ${alto}" preserveAspectRatio="xMidYMid meet">${lineas2.join('')}<path class="g-area" d="${area}"/><path class="g-linea" d="${camino}"/>
        <circle class="g-punto" cx="${puntos[puntos.length - 1][0].toFixed(1)}" cy="${puntos[puntos.length - 1][1].toFixed(1)}" r="4"/>${etiquetasX}</svg>
      </figure>`;
  }

  function fechaPeriodo(r, k) {
    const f0 = r.primerPago;
    const d = new Date(Date.UTC(f0.anio, f0.mes - 1 + (k - 1), 1));
    return F.mesAnio(d.getUTCFullYear(), d.getUTCMonth() + 1);
  }

  function pintarTabla(r) {
    const cond = r.cond;
    $('tablaTitulo').textContent = `${cond.esValora ? 'Valora' : 'Pagos Oportunos'} ${cond.plazo.anios} años · ${r.tipo.nombre}`;
    $('tablaResumen').innerHTML = [
      ['Monto del crédito', F.moneda(r.montoCredito)],
      ['Se liquida por pago puntual en', r.tabla.liquidaPeriodo === null ? '—' : duracion(r.tabla.liquidaAnios, r.tabla.liquidaMeses)],
      ['CAT', F.porcentaje(r.cat, 1)],
      ['Tasa piso · techo', `${F.porcentaje(cond.piso)} · ${F.porcentaje(cond.techo)}`],
      ['Comisión + avalúo', F.moneda(r.gastos.comision + r.gastos.avaluo)]
    ].map(([a, b]) => `<div><span>${a}</span><strong>${b}</strong></div>`).join('');

    const verTodo = $('verTodo').checked;
    const ultimo = verTodo || r.tabla.liquidaPeriodo === null ? r.tabla.filas.length : r.tabla.liquidaPeriodo;
    const filas = r.tabla.filas.slice(0, ultimo);
    const celda = (x) => `<td>${F.numero(x)}</td>`;
    $('tablaCuerpo').innerHTML = filas.map((f) => `<tr${f.k % 12 === 0 ? ' class="fin-anio"' : ''}>
      <th scope="row">${f.k}</th>
      <td class="texto">${f.dias ? fechaPeriodo(r, f.k) : '—'}</td>
      <td>${f.dias || '—'}</td>
      ${celda(f.saldo)}${celda(f.erogacion)}${celda(f.interes)}${celda(f.amortizacion)}
      <td class="editable"><input aria-label="Prepago del periodo ${f.k}" data-periodo="${f.k}" inputmode="decimal" value="${estado.prepagos[f.k] ? F.escribirMonto(estado.prepagos[f.k]) : ''}"></td>
      ${celda(f.penalizacion)}${celda(f.aportacion)}
      <td>${f.tasa === null ? '—' : F.porcentaje(f.tasa)}</td>
      ${celda(f.saldoFinal)}${celda(f.seguroVida)}${celda(f.seguroDanios)}
      <td class="destacado">${F.numero(f.pagoMensual)}</td>
    </tr>`).join('');

    const t = r.tabla.totales;
    $('tablaPie').innerHTML = `<tr><th scope="row" colspan="4">Totales</th>
      ${celda(t.erogacion)}${celda(t.interes)}${celda(t.amortizacion)}${celda(t.prepago)}<td></td><td></td><td></td><td></td>
      ${celda(t.seguroVida)}${celda(t.seguroDanios)}<td class="destacado">${F.numero(t.pagoMensual)}</td></tr>`;
  }

  function pintarCaratula(r, entrada) {
    const c = r.caratula;
    const cliente = $('nombreCliente').value.trim();
    $('caratula').innerHTML = `
      <div class="caratula__cabeza">
        <div><span>Acreditado</span><strong>${cliente || 'Sin capturar'}</strong></div>
        <div><span>Nombre comercial del producto</span><strong>${c.producto.trim()}</strong></div>
        <div><span>Tipo de crédito</span><strong>Crédito hipotecario</strong></div>
      </div>
      <div class="caratula__cifras">
        <div><span>CAT (Costo Anual Total)</span><strong>${F.porcentaje(c.cat, 1)}</strong><em>Sin IVA. Para fines informativos y de comparación.</em></div>
        <div><span>Tasa de interés anual ordinaria</span><strong>${F.porcentaje(c.tasa)}</strong><em>Tasa fija. No aplica tasa de interés moratoria.</em></div>
        <div><span>Monto o línea de crédito</span><strong>${F.moneda(c.monto)}</strong><em>Moneda nacional.</em></div>
        <div><span>Monto total a pagar</span><strong>${F.moneda(c.totalPagar)}</strong><em>Suma de los pagos mensuales con pago puntual.</em></div>
      </div>
      <div class="caratula__bloques">
        <section><h3>Plazo del crédito</h3><p>${c.plazo || '—'}</p></section>
        <section><h3>Fecha de corte</h3><p>Si la disposición es entre el día 3 y el 16, la fecha de corte es el día 3 de cada mes. Si es entre el día 17 y el 2, es el día 17. En esta cotización: día ${r.primerPago.diaCorte}.</p></section>
        <section><h3>Fecha límite de pago</h3><p>El pago vence el mismo día de la fecha de corte de cada mes.</p></section>
        <section><h3>Comisiones relevantes</h3><ul>
          <li>Contratación del crédito: ${F.moneda(c.comision)}</li>
          <li>Penalización por pago anticipado: ${F.porcentaje(c.penalizacionPrepago, 0)} más IVA sobre el monto anticipado</li>
          <li>Penalización por pago tardío: ${F.moneda(c.penalizacionTardio)} más IVA</li>
        </ul></section>
        <section><h3>Seguros obligatorios</h3><ul>
          <li>Vida y desempleo: ${F.porcentaje(P.SEGUROS.vidaDesempleo, 2)} mensual sobre el saldo insoluto</li>
          <li>Daños y responsabilidad civil: ${F.porcentaje(P.SEGUROS.danios, 3)} mensual sobre el valor destructible</li>
        </ul><p class="nota">El cliente puede contratarlos con un tercero.</p></section>
        <section><h3>Contrato</h3><p>${c.contrato || '—'}</p><p class="nota">Clave ${c.claveContrato} (tipo de crédito · esquema · mancomunado)</p></section>
      </div>
      <section class="caratula__advertencias"><h3>Advertencias</h3><ul>
        <li>Incumplir tus obligaciones te puede generar comisiones e intereses moratorios.</li>
        <li>Contratar créditos que excedan tu capacidad de pago afecta tu historial crediticio.</li>
        <li>El avalista, obligado solidario o coacreditado responde como obligado principal por el total del pago.</li>
      </ul></section>`;
  }

  function recalcular() {
    opcionesDependientes();
    const entrada = construirEntrada();
    const r = M.cotizar(entrada);
    estado.entrada = entrada;
    estado.resultado = r;
    pintarAvisos(r, entrada);
    pintarCotizacion(r, entrada);
    pintarTabla(r);
    pintarCaratula(r, entrada);
    $('metodologia').innerHTML = window.METODOLOGIA.generar(r, entrada);
  }

  function marcarSegmentado(grupo, valor) {
    grupo.querySelectorAll('button').forEach((b) => {
      const activo = Number(b.dataset.valor) === valor;
      b.setAttribute('aria-checked', String(activo));
      b.tabIndex = activo ? 0 : -1;
    });
  }

  function mostrarVista() {
    const nombre = location.hash.replace('#', '');
    const vista = VISTAS.includes(nombre) ? nombre : 'cotizacion';
    VISTAS.forEach((v) => { $(`vista-${v}`).hidden = v !== vista; });
    document.querySelectorAll('.pestanas a').forEach((a) => {
      if (a.dataset.vista === vista) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
    document.body.dataset.vista = vista;
  }

  function avisar(texto) {
    const el = $('mensajeFlotante');
    el.textContent = texto;
    el.hidden = false;
    clearTimeout(avisar.t);
    avisar.t = setTimeout(() => { el.hidden = true; }, 2400);
  }

  function tablaComoTexto() {
    const r = estado.resultado;
    const encabezado = ['Periodo', 'Días', 'Saldo inicial', 'Erogación', 'Interés', 'Amortización', 'Prepagos', 'Penalización', 'Aportación', 'Tasa', 'Saldo final', 'Seguro vida', 'Seguro daños', 'Pago mensual'];
    const ultimo = $('verTodo').checked || r.tabla.liquidaPeriodo === null ? r.tabla.filas.length : r.tabla.liquidaPeriodo;
    const filas = r.tabla.filas.slice(0, ultimo).map((f) => [f.k, f.dias, f.saldo, f.erogacion, f.interes, f.amortizacion, f.prepago, f.penalizacion, f.aportacion, f.tasa === null ? '' : f.tasa, f.saldoFinal, f.seguroVida, f.seguroDanios, f.pagoMensual]
      .map((x) => (typeof x === 'number' ? String(Math.round(x * 1e6) / 1e6) : x)).join('\t'));
    return [encabezado.join('\t')].concat(filas).join('\n');
  }

  function formatearAlSalir(e) {
    const el = e.target;
    if (el.dataset.tipo === 'moneda') {
      const v = F.leerMonto(el.value);
      el.value = v === null ? '' : F.escribirMonto(v);
    }
  }

  function limpiar() {
    CAMPOS_MONEDA.concat(CAMPOS_PORCENTAJE).forEach((id) => { $(id).value = ''; });
    $('fecha').value = F.hoyISO();
    $('segurosExternos').checked = false;
    $('gastosFinanciados').value = 'SI';
    estado.prepagos = {};
    recalcular();
    $('dato').focus();
  }

  function iniciar() {
    llenarSelect($('tipoCredito'), P.TIPOS_CREDITO.map((t) => ({ valor: t.id, texto: t.nombre })));
    $('tipoCredito').value = VALORES_INICIALES.tipoCredito;
    llenarSelect($('campana'), P.CAMPANAS.map((c) => ({ valor: c.id, texto: c.nombre })));
    $('campana').value = VALORES_INICIALES.campana;
    opcionesDependientes();
    ['plazo', 'indiceTasa', 'actividad', 'tipoComision', 'reduccion'].forEach((id) => { $(id).value = VALORES_INICIALES[id]; });
    $('fecha').value = F.hoyISO();
    $('dato').value = F.escribirMonto(VALORES_INICIALES.dato);
    marcarSegmentado($('producto'), estado.producto);
    marcarSegmentado($('modoCalculo'), estado.modoCalculo);

    [['producto', 'producto'], ['modoCalculo', 'modoCalculo']].forEach(([id, clave]) => {
      const grupo = $(id);
      grupo.addEventListener('click', (e) => {
        const b = e.target.closest('button');
        if (!b) return;
        estado[clave] = Number(b.dataset.valor);
        marcarSegmentado(grupo, estado[clave]);
        recalcular();
      });
      grupo.addEventListener('keydown', (e) => {
        if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
        const botones = [...grupo.querySelectorAll('button')];
        const i = botones.findIndex((b) => b.getAttribute('aria-checked') === 'true');
        const j = (i + (e.key === 'ArrowRight' ? 1 : -1) + botones.length) % botones.length;
        botones[j].click();
        botones[j].focus();
      });
    });

    $('formulario').addEventListener('input', (e) => {
      if (e.target.matches('input')) recalcular();
    });
    $('formulario').addEventListener('change', recalcular);
    $('formulario').addEventListener('focusout', formatearAlSalir);
    $('formulario').addEventListener('submit', (e) => e.preventDefault());

    $('usarMaximo').addEventListener('click', () => {
      $('creditoSolicitado').value = '';
      recalcular();
    });
    $('limpiar').addEventListener('click', limpiar);
    $('reduccion').addEventListener('change', recalcular);
    $('verTodo').addEventListener('change', () => pintarTabla(estado.resultado));

    $('tablaCuerpo').addEventListener('change', (e) => {
      const el = e.target;
      if (!el.dataset.periodo) return;
      const v = F.leerMonto(el.value);
      if (v === null || v === 0) delete estado.prepagos[el.dataset.periodo];
      else estado.prepagos[el.dataset.periodo] = v;
      recalcular();
    });
    $('quitarPrepagos').addEventListener('click', () => {
      estado.prepagos = {};
      recalcular();
    });
    $('copiarTabla').addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(tablaComoTexto());
        avisar('Tabla copiada. Pégala en Excel o en una hoja de cálculo.');
      } catch (err) {
        avisar('El navegador no permitió copiar la tabla.');
      }
    });
    $('imprimir').addEventListener('click', () => {
      try { window.print(); } catch (err) { avisar('Abre la página en una pestaña propia para imprimir.'); }
    });

    window.addEventListener('hashchange', mostrarVista);
    mostrarVista();
    recalcular();
  }

  document.addEventListener('DOMContentLoaded', iniciar);
})();
