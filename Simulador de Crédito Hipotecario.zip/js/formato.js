(function (raiz) {
  'use strict';

  const fmtMoneda = new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtNumero = new Intl.NumberFormat('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const fmtEntero = new Intl.NumberFormat('es-MX', { maximumFractionDigits: 0 });
  const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

  const esNumero = (x) => typeof x === 'number' && Number.isFinite(x);

  const FORMATO = {
    moneda: (x) => (esNumero(x) ? fmtMoneda.format(x).replace('MX$', '$') : '—'),
    numero: (x) => (esNumero(x) ? fmtNumero.format(x) : '—'),
    entero: (x) => (esNumero(x) ? fmtEntero.format(x) : '—'),
    porcentaje: (x, decimales = 2) => (esNumero(x) ? `${(x * 100).toFixed(decimales)}%` : '—'),
    fechaCorta: (anio, mes, dia) => `${String(dia).padStart(2, '0')} ${MESES[mes - 1]} ${anio}`,
    mesAnio: (anio, mes) => `${MESES[mes - 1]} ${anio}`,
    leerMonto(texto) {
      if (texto === null || texto === undefined) return null;
      const limpio = String(texto).replace(/[^0-9.\-]/g, '');
      if (limpio === '' || limpio === '-' || limpio === '.') return null;
      const n = Number(limpio);
      return Number.isFinite(n) ? n : null;
    },
    escribirMonto: (x) => (esNumero(x) ? fmtNumero.format(x) : ''),
    hoyISO() {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    }
  };

  raiz.FORMATO = FORMATO;
})(this);
