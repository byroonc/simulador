(function (raiz) {
  'use strict';

  const TIPOS_CREDITO = [
    { id: 1, nombre: 'Adquisición Tradicional', comercial: 'CREDIRESIDENCIAL', comisionApertura: 0.0125, comisionPrepago: 0.03, aforo: 'sinApoyo', ingresoMinimo: 10000, creditoMinimo: 250000, valorMinimo: 400000, pti: 0.55 },
    { id: 2, nombre: 'Adquisición con Apoyo Infonavit', comercial: 'CREDIRESIDENCIAL', comisionApertura: 0.0075, comisionPrepago: 0, aforo: 'conApoyo', ingresoMinimo: 7500, creditoMinimo: 250000, valorMinimo: 400000, pti: 0.65 },
    { id: 3, nombre: 'Cofinavit', comercial: 'CREDIRESIDENCIAL', comisionApertura: 0.0075, comisionPrepago: 0, aforo: 0.95, ingresoMinimo: 7500, creditoMinimo: 120000, valorMinimo: 300000, pti: 0.65 },
    { id: 4, nombre: 'Pasivo Hipotecario', comercial: 'CREDIRESIDENCIAL', comisionApertura: 0, comisionPrepago: 0.03, aforo: 'sinApoyo', ingresoMinimo: 10000, creditoMinimo: 125000, valorMinimo: 0, pti: 0.65 },
    { id: 5, nombre: 'Pasivo Hipotecario con Apoyo Infonavit', comercial: 'CREDIRESIDENCIAL', comisionApertura: 0, comisionPrepago: 0.03, aforo: 'conApoyo', ingresoMinimo: 10000, creditoMinimo: 125000, valorMinimo: 0, pti: 0.65 },
    { id: 6, nombre: 'Liquidez Vivienda', comercial: 'CREDILIQUIDEZ', comisionApertura: 0.0125, comisionPrepago: 0.03, aforo: 'sinApoyo', ingresoMinimo: 20000, creditoMinimo: 150000, valorMinimo: 1000000, pti: 0.55 },
    { id: 7, nombre: 'CI+CB Cofinavit', comercial: 'CREDIRESIDENCIAL', comisionApertura: 0.0125, comisionPrepago: 0, aforo: 0.9, ingresoMinimo: 10000, creditoMinimo: 250000, valorMinimo: 300000, pti: 0.55 }
  ];

  const INDICES_RIESGO = ['1, 1+', '2, 2+', '3, 3+', '4, 4+', 'R'];

  const AFOROS = {
    conApoyo: [0.95, 0.95, 0.95, 0.85, 0.85],
    empleado: [0.95, 0.95, 0.90, 0.85, 0.85],
    independiente: [0.90, 0.90, 0.85, 0.75, 0.75],
    independientePasivo: [0.95, 0.95, 0.95, 0.85, 0.85]
  };

  const PLAZOS = [
    { id: 1, anios: 7, meses: 84 },
    { id: 2, anios: 10, meses: 120 },
    { id: 3, anios: 15, meses: 180 },
    { id: 4, anios: 20, meses: 240 }
  ];

  const CAMPANAS = [
    {
      id: 1, nombre: 'Ninguna',
      valora: [
        { tasa: 0.12, ppm: { 10: 13.63, 15: 11.32, 20: 10.36 }, incremento: 0.02 },
        { tasa: 0.125, ppm: { 10: 14.06, 15: 11.78, 20: 10.84 }, incremento: 0.017 },
        { tasa: 0.13, ppm: { 10: 14.5, 15: 12.22, 20: 11.28 }, incremento: 0.014 },
        { tasa: 0.135, ppm: { 10: 14.9, 15: 12.63, 20: 11.7 }, incremento: 0.011 },
        { tasa: 0.14, ppm: { 10: 15.3, 15: 13.04, 20: 12.13 }, incremento: 0.007 }
      ],
      piso: 0.12, techo: 0.14,
      pagosOportunos: { 7: { tasa: 0.13, ppm: 18.38 }, 10: { tasa: 0.13, ppm: 15.05 }, 15: { tasa: 0.13, ppm: 12.79 }, 20: { tasa: 0.13, ppm: 11.86 } }
    },
    {
      id: 2, nombre: 'WM',
      valora: [{ tasa: 0.095, ppm: { 10: 11.98, 15: 9.5, 20: 8.38 }, incremento: 0.026 }],
      piso: 0.095, techo: 0.115,
      pagosOportunos: { 7: { tasa: 0.095, ppm: 16.42 }, 10: { tasa: 0.095, ppm: 13.02 }, 15: { tasa: 0.095, ppm: 10.53 }, 20: { tasa: 0.095, ppm: 9.42 } }
    },
    {
      id: 3, nombre: 'Premium',
      valora: [{ tasa: 0.0975, ppm: { 10: 12.12, 15: 9.64, 20: 8.54 }, incremento: 0.026 }],
      piso: 0.0975, techo: 0.1175,
      pagosOportunos: { 7: { tasa: 0.0975, ppm: 16.55 }, 10: { tasa: 0.0975, ppm: 13.16 }, 15: { tasa: 0.0975, ppm: 10.7 }, 20: { tasa: 0.0975, ppm: 9.59 } }
    },
    {
      id: 4, nombre: 'Vinculación',
      valora: [{ tasa: 0.1075, ppm: { 10: 12.75, 15: 10.33, 20: 9.3 }, incremento: 0.024 }],
      piso: 0.1075, techo: 0.1275,
      pagosOportunos: { 7: { tasa: 0.1075, ppm: 17.1 }, 10: { tasa: 0.1075, ppm: 13.73 }, 15: { tasa: 0.1075, ppm: 11.32 }, 20: { tasa: 0.1075, ppm: 10.27 } }
    },
    {
      id: 5, nombre: 'Hipoteca Green', soloTipo: 1,
      valora: [{ tasa: 0.10, ppm: { 10: 12.24, 15: 9.78, 20: 8.7 }, incremento: 0.026 }],
      piso: 0.10, techo: 0.12,
      pagosOportunos: { 7: { tasa: 0.10, ppm: 16.7 }, 10: { tasa: 0.10, ppm: 13.3 }, 15: { tasa: 0.10, ppm: 10.84 }, 20: { tasa: 0.10, ppm: 9.75 } }
    }
  ];

  const AJUSTES_TASA = {
    pagosOportunos: { 13: 0.002, 25: 0.002, 37: 0.002, 49: 0.0015 },
    valora: { desdeMes: 37, hastaMes: 229, cadaMeses: 12, reduccion: 0.0025 }
  };

  const CALENDARIO = {
    periodos: 240,
    incrementoPago: { desde: 13, hasta: 229, cada: 12 },
    incrementoAportacion: { desde: 14, hasta: 230, cada: 12 }
  };

  const AVALUOS = [
    [0.01, 1900], [500001, 3300], [1000001, 4500], [1500001, 5750], [2000001, 7000], [2500001, 8200],
    [3000001, 11000], [4000001, 13900], [5000001, 15500], [6000001, 19000], [7000001, 20000],
    [8000001, 20100], [9000001, 22500], [10000001, 27000], [11000001, 28000], [12000001, 30000],
    [13000001, 32000], [14000001, 34000], [15000001, 37000], [20000001, 39000], [25000001, 40000],
    [30000001, 40000]
  ];
  const AVALUO_LIMITE_COTIZAR = 30000000;

  const GASTOS = {
    impuestosDerechos: 0.03,
    honorariosNotariales: 0.02,
    infonavitOriginacion: 0.03,
    gastosFinanciadosPasivo: 0.06
  };

  const SEGUROS = { vidaDesempleo: 0.0006, danios: 0.00031 };

  const IVA = 0.16;
  const DIAS_ANIO_COMERCIAL = 360;
  const LTI_VALORA = 25;

  const INFONAVIT = {
    montoMaximoCICB: 885445.6,
    porcionCICB: 0.30,
    uma: 117.31,
    topeVecesUma: 25,
    aportacionPatronal: 0.05,
    diasBimestre: 60.8,
    incrementoAnualAportacion: 0.03
  };

  const MONTO_MAXIMO_POLITICA = { general: 15000000, indiceR: 7000000 };

  const PENALIZACION_PAGO_TARDIO = { general: 500, cicbConyugalPO: 350 };

  const CONTRATOS = [
    { clave: '1-2-1', nombre: 'Adquisición Pagos Oportunos' },
    { clave: '2-2-1', nombre: 'Adquisición Con Apoyo Pagos Oportunos' },
    { clave: '1-1-1', nombre: 'Adquisición Valora' },
    { clave: '2-1-1', nombre: 'Adquisición Con Apoyo Valora' },
    { clave: '4-2-1', nombre: 'Pago de Pasivos Pagos Oportunos' },
    { clave: '4-1-1', nombre: 'Pago de Pasivos Valora' },
    { clave: '6-2-1', nombre: 'Liquidez Vivienda Pagos Oportunos' },
    { clave: '6-1-1', nombre: 'Liquidez Vivienda Valora' },
    { clave: '3-2-1', nombre: 'Cofinavit Pagos Oportunos' },
    { clave: '3-2-2', nombre: 'Cofinavit Conyugales Pagos Oportunos' },
    { clave: '3-1-1', nombre: 'Cofinavit Valora' },
    { clave: '3-1-2', nombre: 'Cofinavit Conyugales Valora' },
    { clave: '5-2-1', nombre: 'Pago de Pasivos Pagos Oportunos con Apoyo Infonavit' },
    { clave: '5-1-1', nombre: 'Pago de Pasivos Valora con Apoyo Infonavit' },
    { clave: '7-1-1', nombre: 'Cofinavit CI+CB Valora' },
    { clave: '7-1-2', nombre: 'Cofinavit CI+CB Conyugal Valora' },
    { clave: '7-2-1', nombre: 'Cofinavit CI+CB Pagos Oportunos' },
    { clave: '7-2-2', nombre: 'Cofinavit CI+CB Conyugal Pagos Oportunos' }
  ];

  const PARAMETROS = {
    TIPOS_CREDITO, INDICES_RIESGO, AFOROS, PLAZOS, CAMPANAS, AJUSTES_TASA, AVALUOS, AVALUO_LIMITE_COTIZAR,
    CALENDARIO, GASTOS, SEGUROS, IVA, DIAS_ANIO_COMERCIAL, LTI_VALORA, INFONAVIT, MONTO_MAXIMO_POLITICA,
    PENALIZACION_PAGO_TARDIO, CONTRATOS
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = PARAMETROS;
  else raiz.PARAMETROS = PARAMETROS;
})(this);
